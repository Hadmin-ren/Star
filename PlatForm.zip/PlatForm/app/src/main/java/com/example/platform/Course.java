package com.example.platform;

public class Course {
    private String name;
    private String teacher;
    private String intro;
    private int imageId;
    public Course(String name, String teacher, String intro, int imageId){
        this.name = name;
        this.teacher = teacher;
        this.intro = intro;
        this.imageId = imageId;
    }

    public String getName(){
        return name;
    }

    public String getTeacher(){
        return teacher;
    }

    public String getIntro(){ return intro; }

    public int getImageId(){
        return imageId;
    }
}
