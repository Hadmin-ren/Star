package com.example.platform;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import java.util.List;

public class CourseAdapter extends ArrayAdapter<Course> {

    private int resourceId;

    public CourseAdapter(Context context, int textViewResourceId, List<Course> objects) {
        super(context, textViewResourceId, objects);
        resourceId = textViewResourceId;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Course course = getItem(position);
        View view;
        ViewHolder viewHolder;
        if(convertView == null){
            view = LayoutInflater.from(getContext()).inflate(resourceId, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.courseImage = (ImageView) view.findViewById(R.id.course_image);
            viewHolder.courseName = (TextView) view.findViewById(R.id.coures_name);
            viewHolder.courseTeacher = (TextView) view.findViewById(R.id.coures_teacher);
            viewHolder.courseIntro = (TextView) view.findViewById(R.id.coures_intro);
            view.setTag(viewHolder);
        }else{
            view = convertView;
            viewHolder = (ViewHolder) view.getTag();
        }

        viewHolder.courseName.setText(course.getName());
        viewHolder.courseTeacher.setText(course.getTeacher());
        viewHolder.courseIntro.setText(course.getIntro());
        viewHolder.courseImage.setImageResource(course.getImageId());
        return view;
    }

    private class ViewHolder {
        ImageView courseImage;
        TextView courseName;
        TextView courseTeacher;
        TextView courseIntro;
    }
}
