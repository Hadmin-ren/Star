package com.example.platform;

public class Help {
    public static String name=null;
}
