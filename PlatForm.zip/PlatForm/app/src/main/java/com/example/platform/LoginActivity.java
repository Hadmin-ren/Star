package com.example.platform;


import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;


public class LoginActivity extends AppCompatActivity {

    private EditText nameEdit;
    private EditText pwdEdit;
    private MyView loginView;

    private Handler handler=new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            if(msg.what==1){
                Toast.makeText(LoginActivity.this,"登录成功",Toast.LENGTH_SHORT).show();
                Intent intent=new Intent();
                intent.setClass(LoginActivity.this,MainActivity.class);
                startActivity(intent);

            }else {
                Toast.makeText(LoginActivity.this,"登录失败",Toast.LENGTH_SHORT).show();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        nameEdit=findViewById(R.id.nameEdit);
        pwdEdit=findViewById(R.id.pwdEdit);
        loginView=findViewById(R.id.loginView);
        loginView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_UP){
                    Bitmap bitmap= BitmapFactory.decodeResource(getResources(),R.drawable.login);
                    loginView.replacePic(bitmap);
                }else {
                    Bitmap bitmap= BitmapFactory.decodeResource(getResources(),R.drawable.login_highlight);
                    loginView.replacePic(bitmap);
                }
                return false;
            }
        });
        View.OnFocusChangeListener focusChangeListener=new View.OnFocusChangeListener(){
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                EditText editText=(EditText)v;
                if(editText.hasFocus()){
                    String hint=editText.getHint().toString();
                    editText.setTag(hint);
                    editText.setHint("");
                }else{
                    editText.setHint(editText.getTag().toString());
                }
            }
        };
        nameEdit.setOnFocusChangeListener(focusChangeListener);
        pwdEdit.setOnFocusChangeListener(focusChangeListener);
    }

    public void loginClick(View view){

        new Thread(){
            @Override
            public void run() {
                String pwd=Student.getPwdById(nameEdit.getText().toString());
                Message msg=new Message();
                if(pwdEdit.getText().toString().equals((pwd))){
                    msg.what=1;
                    Help.name=nameEdit.getText().toString();
                }else {
                    msg.what=0;
                }
                handler.sendMessage(msg);
            }
        }.start();
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        startActivity(intent);
    }


    public void registerClick(View view){
        Intent intent=new Intent();
        intent.setClass(LoginActivity.this,RegisterActivity.class);
        startActivity(intent);
    }
}
