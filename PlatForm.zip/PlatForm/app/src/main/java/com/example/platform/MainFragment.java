package com.example.platform;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainFragment extends Fragment {

    private List<Icon> IconList=new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=LayoutInflater.from(this.getActivity()).inflate(R.layout.fragment_main,null);
        initIcons();
        RecyclerView recyclerView=view.findViewById(R.id.recycler_view);
        LinearLayoutManager layoutManager=new LinearLayoutManager(view.getContext());
        layoutManager.setOrientation(LinearLayoutManager.HORIZONTAL);
        recyclerView.setLayoutManager(layoutManager);
        iconAdapter adapter=new iconAdapter(IconList);
        recyclerView.setAdapter(adapter);
        return view;
    }

    private void initIcons(){
        Icon zero=new Icon("我的微专业",R.drawable.ic_category_0);
        IconList.add(zero);
        Icon one=new Icon("滴，打卡",R.drawable.ic_category_1);
        IconList.add(one);
        Icon two=new Icon("期末结业证书",R.drawable.ic_category_2);
        IconList.add(two);
        Icon three=new Icon("免费好课",R.drawable.ic_category_3);
        IconList.add(three);
    }

}
