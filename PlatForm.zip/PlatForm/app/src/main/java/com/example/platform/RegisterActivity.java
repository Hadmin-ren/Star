package com.example.platform;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class  RegisterActivity extends AppCompatActivity {

    private EditText nameText;
    private EditText pwdText;
    private EditText confirmPwdText;

    private Handler handler=new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            if(msg.what==1){
                Toast.makeText(RegisterActivity.this,"注册成功",Toast.LENGTH_SHORT).show();
            }else {
                Toast.makeText(RegisterActivity.this,"注册失败",Toast.LENGTH_SHORT).show();
            }
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        System.out.println("1");
        nameText=findViewById(R.id.nameEdit);
        pwdText=findViewById(R.id.pwdEdit);
        confirmPwdText=findViewById(R.id.confirmPwdEdit);
        System.out.println("2");
    }

    public void registerClick(View view){
        System.out.println("点击注册按钮");
        if(nameText.getText().toString().equals("")){
            Toast.makeText(this,"用户名不得为空",Toast.LENGTH_LONG).show();
            return;
        }
        if(pwdText.getText().toString().equals("")){
            Toast.makeText(this,"密码不得为空",Toast.LENGTH_LONG).show();
            return;
        }
        if(pwdText.getText().toString().equals(confirmPwdText.getText().toString())){
            System.out.println("开始添加数据...");
            new Thread(){
                @Override
                public void run() {
                    Message msg=new Message();
                    if(Register.addStudent(nameText.getText().toString(),pwdText.getText().toString())){
                        msg.what=1;
                    }else {
                        msg.what=0;
                    }
                    handler.sendMessage(msg);
                }
            }.start();
            Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
            startActivity(intent);
        }else {
            Toast.makeText(this,"密码不一致",Toast.LENGTH_LONG).show();
        }
    }
}
